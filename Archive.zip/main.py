import lambda_function
def run():
    lambda_function.lambda_handler()

if __name__ == '__main__':
    run();